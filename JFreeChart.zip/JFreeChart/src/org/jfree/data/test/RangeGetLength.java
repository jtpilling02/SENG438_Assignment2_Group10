package org.jfree.data.test;
import static org.junit.Assert.*; import org.jfree.data.Range; import org.junit.*;

public class RangeGetLength {
    private Range exampleRange1; // declaring ranges to be used for testing
    private Range exampleRange2;
    private Range exampleRange3;
    private Range exampleRange4;

    @Before
    public void setUp() throws Exception { // initializing all the ranges used for testing
    	exampleRange1 = new Range(-1, 1);
    	exampleRange2 = new Range(-2147483647, -2);
    	exampleRange3 = new Range(3, 2147483647);
    	exampleRange4 = new Range(1, 6);
    }

    @Test
    public void postomax_containsmax() { // testing a range from some +ve integer to the max integer
        assertTrue("the result should be true, indicating the range (3, 2147483647) contains 2147483647",
       exampleRange3.contains(2147483647)); // expected: range contains max integer
    }
    
    @Test
    public void negtopos_containszero() { // testing a range from some -ve integer to a +ve integer
        assertTrue("the result should be true, indicating the range (-1, 1) contains 0",
       exampleRange1.contains(0)); // expected: range contains 0
    }
    
    @Test
    public void negtomin_containsmin() { // testing a range from min -ve integer to some -ve int
        assertTrue("the result should be true, indicating the range (-2147483647, -2) contains -2147483647",
       exampleRange2.contains(-2147483647)); // expected: range contains min integer
    }
    
    @Test
    public void postopos_notcontainsneg() { // testing to ensure ranges only containing +ve int does not contain -ve
        assertFalse("the result should be true, indicating the range (1, 6) does not contains -1",
       exampleRange4.contains(-1)); // expected: does not contain -1
    }

    @After
    public void tearDown() throws Exception { // teardown
    }
}