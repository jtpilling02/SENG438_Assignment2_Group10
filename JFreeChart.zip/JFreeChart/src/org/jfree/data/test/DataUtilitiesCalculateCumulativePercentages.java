package org.jfree.data.test;

import static org.junit.Assert.*;

import org.jfree.data.DataUtilities;
import org.jfree.data.DefaultKeyedValues;
import org.jfree.data.KeyedValues;
import org.jmock.*;
import org.junit.*;

public class DataUtilitiesCalculateCumulativePercentages extends DataUtilities{

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}
	
	@Test
	public void givenMockTable_getCumulativePercentagesForThreePositiveValues() {
		DefaultKeyedValues newtable = new DefaultKeyedValues();
		newtable.addValue("0", 5);
		newtable.addValue("1", 9);
		newtable.addValue("2", 2);
		KeyedValues newresult = new DefaultKeyedValues();
		newresult = DataUtilities.getCumulativePercentages(newtable);
		assertEquals(0.3125, newresult.getValue(0));
		assertEquals(0.875, newresult.getValue(1));
		assertEquals(1.0, newresult.getValue(2));
	}
	
	@Test
	public void givenSingleRowTable_getCumulativePercentages() {
		// setup
	    Mockery mockingContext = new Mockery();
	    final KeyedValues values = mockingContext.mock(KeyedValues.class);
	    mockingContext.checking(new Expectations() {
	        {
	            allowing(values).getItemCount();
	            will(returnValue(1));
	            allowing(values).getValue(0);
	            will(returnValue(10));
	            allowing(values).getKey(0);
	            will(returnValue(0));
	        }
	    });
		KeyedValues result = DataUtilities.getCumulativePercentages(values);
		assertEquals(1.0, result.getValue(0));
	}
	
	@Test
	public void givenThreeRowsTable_getCumulativePercentages() {
		// setup
	    Mockery mockingContext = new Mockery();
	    final KeyedValues values = mockingContext.mock(KeyedValues.class);
	    mockingContext.checking(new Expectations() {
	        {
	            allowing(values).getItemCount();
	            will(returnValue(3));
	            allowing(values).getValue(0);
	            will(returnValue(5));
	            allowing(values).getKey(0);
	            will(returnValue(0));
	            allowing(values).getValue(1);
	            will(returnValue(9));
	            allowing(values).getKey(1);
	            will(returnValue(1));
	            allowing(values).getValue(2);
	            will(returnValue(2));
	            allowing(values).getKey(2);
	            will(returnValue(2));
	        }
	    });
		KeyedValues result = DataUtilities.getCumulativePercentages(values);
		assertEquals(0.3125, result.getValue(0));
		assertEquals(0.875, result.getValue(1));
		assertEquals(1.0, result.getValue(2));
	}
	
	@Test
	public void givenThreeEmptyRowsTable_getCumulativePercentages() {
		// setup
	    Mockery mockingContext = new Mockery();
	    final KeyedValues values = mockingContext.mock(KeyedValues.class);
	    mockingContext.checking(new Expectations() {
	        {
	            allowing(values).getItemCount();
	            will(returnValue(3));
	            allowing(values).getValue(0);
	            will(returnValue(0));
	            allowing(values).getKey(0);
	            will(returnValue(0));
	            allowing(values).getValue(1);
	            will(returnValue(0));
	            allowing(values).getKey(1);
	            will(returnValue(1));
	            allowing(values).getValue(2);
	            will(returnValue(0));
	            allowing(values).getKey(2);
	            will(returnValue(2));
	        }
	    });
		KeyedValues result = DataUtilities.getCumulativePercentages(values);
		boolean isNan = Double.isNaN((double)result.getValue(0));
		assertTrue(isNan);
	}
	
	@Test
	public void givenThreeNegativeRowsTable_getCumulativePercentages() {
		// setup
	    Mockery mockingContext = new Mockery();
	    final KeyedValues values = mockingContext.mock(KeyedValues.class);
	    mockingContext.checking(new Expectations() {
	        {
	            allowing(values).getItemCount();
	            will(returnValue(3));
	            allowing(values).getValue(0);
	            will(returnValue(-20));
	            allowing(values).getKey(0);
	            will(returnValue(0));
	            allowing(values).getValue(1);
	            will(returnValue(-40));
	            allowing(values).getKey(1);
	            will(returnValue(1));
	            allowing(values).getValue(2);
	            will(returnValue(-40));
	            allowing(values).getKey(2);
	            will(returnValue(2));
	        }
	    });
		KeyedValues result = DataUtilities.getCumulativePercentages(values);
		assertEquals(0.2, result.getValue(0));
		assertEquals(0.6, result.getValue(1));
		assertEquals(1.0, result.getValue(2));
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}
}
