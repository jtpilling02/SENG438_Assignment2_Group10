package org.jfree.data.test;

import static org.junit.Assert.*;

import org.jfree.data.DataUtilities;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * @author Luis Miranda
 *
 */
public class DataUtilitiesCreateNumberArray2D extends DataUtilities {
	// Instantiate global variables
	double[][] input2DArray;
	double[][] null2DArray;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		input2DArray = new double[][] {{-11231.234E23, 12331.4123E2, 2.0},
									  {9.0, 5.0, -123849.82830239},
									  {23093023.1233, 2039102.32, -49302.203E123},
									  {-3.0, 1235.23, 94759309}
		   							  };
	}
	
	/**
	 * Testing null values and if the method throws the right exception
	 */
	@Test(expected = IllegalArgumentException.class)
	public void createNumberArrayTestNull() {
		DataUtilities.createNumberArray2D(null);
	}
	
	/**
	 * checking if the Number Array had been instantiated properly
	 * there seems to be a bug with the index
	 */
	@Test
	public void testcreateNumberArray2D()
	{
		Number[][] actual = DataUtilities.createNumberArray2D(input2DArray);
		Number[][] expected = new Number[][]{{-11231.234E23, 12331.4123E2, 2.0},
										     {9.0, 5.0, -123849.82830239},
										   	 {23093023.1233, 2039102.32, -49302.203E123},
										   	 {-3.0, 1235.23, 94759309}
										   	};
										   
		
		assertEquals("Array contents must be equal.", input2DArray[2][0],
				actual[2][0].doubleValue(), 0.0000001);
		assertEquals("Array contents must be equal.", input2DArray[2][1],
				actual[2][1].doubleValue(), 0.0000001);
		assertEquals("Array contents must be equal.", input2DArray[3][1],
				actual[3][1].doubleValue(), 0.0000001);
	}
	
	
	/**
	 * Bug in the method as there should be an element at actual if all the 
	 * elements have been converted but there the method throws
	 * a NullPointerException
	 */
	@Test(expected = NullPointerException.class)
	public void testcreateNumberArrayIndex()
	{
		Number[][] actual = DataUtilities.createNumberArray2D(input2DArray);
		Number[][] expected = new Number[][]{{-11231.234E23, 12331.4123E2, 2.0},
		     								 {9.0, 5.0, -123849.82830239},
		     								 {23093023.1233, 2039102.32, -49302.203E123},
		     								 {-3.0, 1235.23, 94759309}
		   									};
		assertEquals("Array contents must be equal.", input2DArray[0][2],
				actual[0][2].doubleValue(), 0.0000001);

	}
	
	/**
	 * Tests if the length of the 2D array created by "createNumberArray2D"
	 * is correct
	 */
	@Test
	public void testArrayLength()
	{	
		Number[][] actual = DataUtilities.createNumberArray2D(input2DArray);
		Number[][] expected = new Number[][]{{-11231.234E23, 12331.4123E2, 2.0},
		     								 {9.0, 5.0, -123849.82830239},
		     								 {23093023.1233, 2039102.32, -49302.203E123},
		     								 {-3.0, 1235.23, 94759309}
		   									};
		assertEquals("Array Length (number of rows) must be equal", input2DArray.length,
				actual.length, 0.0000001);
	}
	
	/**
	 * Tests if the length of each row of the 2D array 
	 * created by "createNumberArray2D" is correct
	 */
	@Test
	public void testArrayRowLength()
	{	
		Number[][] actual = DataUtilities.createNumberArray2D(input2DArray);
		Number[][] expected = new Number[][]{{-11231.234E23, 12331.4123E2, 2.0},
		     								 {9.0, 5.0, -123849.82830239},
		     								 {23093023.1233, 2039102.32, -49302.203E123},
		     								 {-3.0, 1235.23, 94759309}
		   									};
		   									
		 for(int i = 0; i < input2DArray.length; i++) 
		 {		
				assertEquals("Array Length (number of rows) must be equal", input2DArray[i].length,
						actual[i].length, 0.0000001);
		 }

	}
	
	@After
	public void tearDown() throws Exception {
	}
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

}
