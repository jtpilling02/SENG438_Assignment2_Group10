package org.jfree.data.test;

import static org.junit.Assert.*; import org.jfree.data.Range; import org.junit.*;

public class RangeCentralValue {
	/**
	 * A class to find the central value of a range.
	 */
    private Range exampleRange;
    @BeforeClass public static void setUpBeforeClass() throws Exception {
    }
    
    @Test
    /**
     * Finds the central value of a negative and positive number.
     */
    public void centralValueOfNegativePositive() {
    	exampleRange = new Range(-9, 3);
    	assertEquals("The central value of -9 and 3 should be -3",
        -3, exampleRange.getCentralValue(), .000000001d);
    }
    
    
    @Test
    /**
     * Finds the central value of two negative numbers.
     */
    public void centralValueOfNegativeNegative() {
    	exampleRange = new Range(-9, -3);
    	assertEquals("The central value of -9 and 3 should be -6",
        -6, exampleRange.getCentralValue(), .000000001d);
    }
    
    @Test
    /**
     *  Finds the central value of two positive numbers.
     */
    public void centralValueOfPositivePositive() {
    	exampleRange = new Range(3, 9);
    	assertEquals("The central value of 3 and 9 should be 6",
        6, exampleRange.getCentralValue(), .000000001d);
    }
    
    @Test
    /**
     * Finds the central value of the same number twice.
     */
    public void centralValueOfTheSameNumber() {
    	exampleRange = new Range(5, 5);
    	assertEquals("The central value of 5 and 5 should be 5",
        5, exampleRange.getCentralValue(), .000000001d);
    }    
    
    @Test
    /**
     * Finds the central value of the largest int twice.
     */
    public void centralValueOfPositiveMax() {
    	exampleRange = new Range(2147483647, 2147483647);
    	assertEquals("The central value of 2147483647 and 2147483647 should be "
    			+ "2147483647",
    	2147483647, exampleRange.getCentralValue(), .000000001d);
    }
    
    @Test
    /**
     * Finds the central value of the smallest int twice.
     */
    public void centralValueOfNegativeMax() {
    	exampleRange = new Range(-2147483647, -2147483647);
    	assertEquals("The central value of 2147483647 and 2147483647 should be "
    			+ "-2147483647",
    	-2147483647, exampleRange.getCentralValue(), .000000001d);
    }
    
    @Test
    /**
     * Finds the central value of the smallest int and a positive number.
     */
    public void centralValueNegMaxAndPositive() {
    	exampleRange = new Range(-2147483647, 1000);
    	assertEquals("The central value of -2147483647 and 1000 should be"
    			+ "-1073741323.5",
    	-1073741323.5, exampleRange.getCentralValue(), .000000001d);
    }
       
    @Test
    /**
     * Finds the central value of the smallest int and a negative number.
     */
    public void centralValueOfNegMaxAndNegative() {
    	exampleRange = new Range(-2147483647, -1000);
    	assertEquals("The central value of -2147483647 and -1000 should be "
    			+ "-1073742323.5",
    	-1073742323.5, exampleRange.getCentralValue(), .000000001d);
    }
    
    @Test
    /**
     *  Finds the central value of the smallest int and zero.
     */
    public void centralValueOfNegMaxAndZero() {
    	exampleRange = new Range(-2147483647, 0);
    	assertEquals("The central value of -2147483647 and 0 should be "
    			+ "-1073741823.5",
    	-1073741823.5, exampleRange.getCentralValue(), .000000001d);
    }
    
    @Test
    /**
     * Finds the central value of a positive number and the largest int.
     */
    public void centralValueOfPosMaxAndPositive() {
    	exampleRange = new Range(1000, 2147483647);
    	assertEquals("The central value of 1000 and 2147483647 should be "
    			+ "1073742323.5",
    	1073742323.5, exampleRange.getCentralValue(), .000000001d);
    }
    
    @Test
    /**
     * Finds the central value of a negative number and the largest int.
     */
    public void centralValueOfPosMaxAndNegative() {
    	exampleRange = new Range(-1000, 2147483647);
    	assertEquals("The central value of -1000 and 2147483647 should be "
    			+ "1073741323.5",
    	1073741323.5, exampleRange.getCentralValue(), .000000001d);
    }
    
    @Test
    /**
     * Finds the central value of zero and the largest int.
     */
    public void centralValueOfPosMaxAndZero() {
    	exampleRange = new Range(0, 2147483647);
    	assertEquals("The central value of 0 and 2147483647 should be "
    			+ "1073741823.5",
    	1073741823.5, exampleRange.getCentralValue(), .000000001d);
    }
    
    @Ignore
    @Test
    /**
     * Finds the central value of two invalid inputs.
     */
    public void centralValueOfInvalidInputs() {
    	exampleRange = new Range(10, -10);
    	fail("Upper bound is less than central value.");
    }

    @After
    public void tearDown() throws Exception {
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }
}