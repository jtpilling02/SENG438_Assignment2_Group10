package org.jfree.data.test;

import static org.junit.Assert.*;

import org.jfree.data.DataUtilities;
import org.jfree.data.DefaultKeyedValues2D;
import org.jfree.data.Values2D;
import org.jmock.*;
import org.junit.*;

public class DataUtilitiesCalculateColumnTotal extends DataUtilities{
	
	DefaultKeyedValues2D zeroRowsTable = new DefaultKeyedValues2D();
	DefaultKeyedValues2D twoRowsWithPositiveValuesTable = new DefaultKeyedValues2D();

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		twoRowsWithPositiveValuesTable.addValue(2, "Row 1", "Column 1");
		twoRowsWithPositiveValuesTable.addValue(3, "Row 2", "Column 1");
		twoRowsWithPositiveValuesTable.addValue(10, "Row 1", "Column 2");
		twoRowsWithPositiveValuesTable.addValue(20, "Row 2", "Column 2");
		twoRowsWithPositiveValuesTable.addValue(-2, "Row 1", "Column 3");
		twoRowsWithPositiveValuesTable.addValue(6, "Row 2", "Column 3");
	}
	
	@Test
	public void givenZeroRowsTable_whenCalculateColumnTotal_thenReturnZero() {
		double result = DataUtilities.calculateColumnTotal(zeroRowsTable, 0);
		assertEquals(result, 0.0, .000000001d);
	}
	
	@Test
	public void givenPositiveValuedRowsTable_whenCalculateColumnTotal_thenReturnPositive() {
		double result = DataUtilities.calculateColumnTotal(twoRowsWithPositiveValuesTable, 0);
		assertEquals(result, 5.0, .000000001d);
	}
	
	@Test (expected = IndexOutOfBoundsException.class)
	public void givenPositiveValuedRowsTableButNegativeIndex_whenCalculateColumnTotal_thenReturnZero() {
		double result = DataUtilities.calculateColumnTotal(twoRowsWithPositiveValuesTable, -10);
		assertEquals(result, 0.0, .000000001d);
	}
	
	@Test (expected = IndexOutOfBoundsException.class)
	public void givenPositiveValuedRowsTableButWrongIndex_whenCalculateColumnTotal_thenReturnZero() {
		double result = DataUtilities.calculateColumnTotal(twoRowsWithPositiveValuesTable, 10);
		assertEquals(result, 0.0, .000000001d);
	}
	
	@Test
	public void givenPositiveValuedRowsTable_whenCalculateColumnTotalForEdgeColumn_thenReturnPositive() {
		double result = DataUtilities.calculateColumnTotal(twoRowsWithPositiveValuesTable, 2);
		assertEquals(result, 4.0, .000000001d);
	}
	
	@Test
	public void givenMockTable_calculateColumnTotalForThreePositiveValues() {
	    // setup
	    Mockery mockingContext = new Mockery();
	    final Values2D values = mockingContext.mock(Values2D.class);
	    mockingContext.checking(new Expectations() {
	        {
	            one(values).getRowCount();
	            will(returnValue(3));
	            one(values).getValue(0, 0);
	            will(returnValue(2.5));
	            one(values).getValue(1, 0);
	            will(returnValue(2.5));
	            one(values).getValue(2, 0);
	            will(returnValue(3.0));
	        }
	    });
	    double result = DataUtilities.calculateColumnTotal(values, 0);
	    // verify
	    assertEquals(result, 8.0, .000000001d);
	}
	
	@Test
	public void givenMockTable_calculateColumnTotalForThreeNegativeValues() {
	    // setup
	    Mockery mockingContext = new Mockery();
	    final Values2D values = mockingContext.mock(Values2D.class);
	    mockingContext.checking(new Expectations() {
	        {
	            one(values).getRowCount();
	            will(returnValue(3));
	            one(values).getValue(0, 0);
	            will(returnValue(-2.5));
	            one(values).getValue(1, 0);
	            will(returnValue(-2.5));
	            one(values).getValue(2, 0);
	            will(returnValue(-6.0));
	        }
	    });
	    double result = DataUtilities.calculateColumnTotal(values, 0);
	    // verify
	    assertEquals(result, -11.0, .000000001d);
	}
	
	@Test
	public void givenMockTable_calculateColumnTotalForNoValues() {
	    // setup
	    Mockery mockingContext = new Mockery();
	    final Values2D values = mockingContext.mock(Values2D.class);
	    mockingContext.checking(new Expectations() {
	        {
	            one(values).getRowCount();
	            will(returnValue(0));
	        }
	    });
	    double result = DataUtilities.calculateColumnTotal(values, 0);
	    // verify
	    assertEquals(result, 0, .000000001d);
	}
	
	@Test
	public void givenMockTable_calculateColumnTotalForNegativeIndex() {
	    // setup
	    Mockery mockingContext = new Mockery();
	    final Values2D values = mockingContext.mock(Values2D.class);
	    mockingContext.checking(new Expectations() {
	        {
	            one(values).getRowCount();
	            will(returnValue(0));
	        }
	    });
	    double result = DataUtilities.calculateColumnTotal(values, -10);
	    // verify
	    assertEquals(result, 0.0, .000000001d);
	}
	
	@Test
	public void givenMockTable_calculateColumnTotalForOutOfBoundsIndex() {
	    // setup
	    Mockery mockingContext = new Mockery();
	    final Values2D values = mockingContext.mock(Values2D.class);
	    mockingContext.checking(new Expectations() {
	        {
	            one(values).getRowCount();
	            will(returnValue(0));
	        }
	    });
	    double result = DataUtilities.calculateColumnTotal(values, 10);
	    // verify
	    assertEquals(result, 0.0, .000000001d);
	}
	
	@Test
	public void givenMockTable_calculateColumnTotalForEdgeColumn() {
	    // setup
	    Mockery mockingContext = new Mockery();
	    final Values2D values = mockingContext.mock(Values2D.class);
	    mockingContext.checking(new Expectations() {
	        {
	            one(values).getRowCount();
	            will(returnValue(3));
	            one(values).getValue(0, 3);
	            will(returnValue(2.5));
	            one(values).getValue(1, 3);
	            will(returnValue(-2.5));
	            one(values).getValue(2, 3);
	            will(returnValue(3.0));
	            one(values).getValue(0, 0);
	            will(returnValue(0.0));
	            one(values).getValue(1, 0);
	            will(returnValue(-10.0));
	            one(values).getValue(2, 0);
	            will(returnValue(3.0));
	        }
	    });
	    double result = DataUtilities.calculateColumnTotal(values, 3);
	    // verify
	    assertEquals(result, 3.0, .000000001d);
	}
	
	@Test
	public void givenMockTable_calculateColumnTotalForLargeValues() {
	    // setup
	    Mockery mockingContext = new Mockery();
	    final Values2D values = mockingContext.mock(Values2D.class);
	    mockingContext.checking(new Expectations() {
	        {
	            one(values).getRowCount();
	            will(returnValue(3));
	            one(values).getValue(0, 0);
	            will(returnValue(1000000000.0));
	            one(values).getValue(1, 0);
	            will(returnValue(1000000000.0));
	            one(values).getValue(2, 0);
	            will(returnValue(1000999999.0));
	        }
	    });
	    double result = DataUtilities.calculateColumnTotal(values, 0);
	    // verify
	    assertEquals(result, 3000999999.0, .000000001d);
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}
}
