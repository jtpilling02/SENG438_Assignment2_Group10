package org.jfree.data.test;

import static org.junit.Assert.*; import org.jfree.data.Range; import org.junit.*;

public class RangeUpperBound {
	/**
	 * A class to find the upper bound of a range.
	 */
    private Range exampleRange;
    @BeforeClass public static void setUpBeforeClass() throws Exception {
    }

    @Test
    /**
     * Finds the upper bound of a negative and positive number.
     */
    public void upperBoundOfNegativePositive() {
    	exampleRange = new Range(-9, 3);
    	assertEquals("The upper bound of -9 and 3 should be 3",
        3, exampleRange.getUpperBound(), .000000001d);
    }
    
    @Test
    /**
     * Finds the upper bound of two negative numbers.
     */
    public void upperBoundOfNegativeNegative() {
    	exampleRange = new Range(-9, -3);
    	assertEquals("The upper bound of -9 and 3 should be -3",
        -3, exampleRange.getUpperBound(), .000000001d);
    }
    
    @Test
    /**
     *  Finds the upper bound of two positive numbers.
     */
    public void upperBoundOfPositivePositive() {
    	exampleRange = new Range(3, 9);
    	assertEquals("The upper bound of 3 and 9 should be 9",
        9, exampleRange.getUpperBound(), .000000001d);
    }
    
    @Test
    /**
     * Finds the upper bound of the same number twice.
     */
    public void upperBoundOfTheSameNumber() {
    	exampleRange = new Range(5, 5);
    	assertEquals("The upper bound of 5 and 5 should be 5",
        5, exampleRange.getUpperBound(), .000000001d);
    }    
    
    @Test
    /**
     * Finds the upper bound of the largest int twice.
     */
    public void upperBoundOfPositiveMax() {
    	exampleRange = new Range(2147483647, 2147483647);
    	assertEquals("The upper bound of 2147483647 and 2147483647 should be "
    			+ "2147483647",
    	2147483647, exampleRange.getUpperBound(), .000000001d);
    }
    
    @Test
    /**
     * Finds the upper bound of the smallest int twice.
     */
    public void upperBoundOfNegativeMax() {
    	exampleRange = new Range(-2147483647, -2147483647);
    	assertEquals("The upper bound of 2147483647 and 2147483647 should be "
    			+ "-2147483647",
    	-2147483647, exampleRange.getUpperBound(), .000000001d);
    }
    
    @Test
    /**
     * Finds the upper bound of the smallest int and a positive number.
     */
    public void upperBoundNegMaxAndPositive() {
    	exampleRange = new Range(-2147483647, 1000);
    	assertEquals("The upper bound of -2147483647 and 1000 should be 1000",
    	1000, exampleRange.getUpperBound(), .000000001d);
    }
       
    @Test
    /**
     * Finds the upper bound of the smallest int and a negative number.
     */
    public void upperBoundOfNegMaxAndNegative() {
    	exampleRange = new Range(-2147483647, -1000);
    	assertEquals("The upper bound of -2147483647 and -1000 should be -1000",
    	-1000, exampleRange.getUpperBound(), .000000001d);
    }
    
    @Test
    /**
     *  Finds the upper bound of the smallest int and zero.
     */
    public void upperBoundOfNegMaxAndZero() {
    	exampleRange = new Range(-2147483647, 0);
    	assertEquals("The upper bound of 2147483647 and 0 should be 0",
    	0, exampleRange.getUpperBound(), .000000001d);
    }
    
    @Test
    /**
     * Finds the upper bound of a positive number and the largest int.
     */
    public void upperBoundOfPosMaxAndPositive() {
    	exampleRange = new Range(1000, 2147483647);
    	assertEquals("The upper bound of 1000 and 2147483647 should be"
    			+ "2147483647",
    	2147483647, exampleRange.getUpperBound(), .000000001d);
    }
    
    @Test
    /**
     * Finds the upper bound of a negative number and the largest int.
     */
    public void upperBoundOfPosMaxAndNegative() {
    	exampleRange = new Range(-1000, 2147483647);
    	assertEquals("The upper bound of -1000 and 2147483647 should be"
    			+ "2147483647",
    	2147483647, exampleRange.getUpperBound(), .000000001d);
    }
    
    @Test
    /**
     * Finds the upper bound of zero and the largest int.
     */
    public void upperBoundOfPosMaxAndZero() {
    	exampleRange = new Range(0, 2147483647);
    	assertEquals("The upper bound of 0 and 2147483647 should be"
    			+ "2147483647",
    	2147483647, exampleRange.getUpperBound(), .000000001d);
    }
    
    @Ignore
    @Test
    /**
     * Finds the upper bound of two invalid inputs.
     */
    public void upperBoundOfInvalidInputs() {
    	exampleRange = new Range(10, -10);
    	fail("Upper bound is less than upper bound.");
    }
    
    @After
    public void tearDown() throws Exception {
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }
}